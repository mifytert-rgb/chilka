package com.chilka.island

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.view.View
import android.view.accessibility.AccessibilityEvent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.graphics.BitmapFactory
import java.io.File
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.view.KeyEvent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
import android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
import android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
import android.view.WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
import android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
import android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.Toast
import android.media.session.MediaSession
import android.os.PowerManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.roundToInt
import android.content.BroadcastReceiver
import android.content.IntentFilter

class IslandService : AccessibilityService() {

    companion object {
        @Volatile var running = false
        const val ACTION_CFG = "com.chilka.island.CFG"
        private const val CH = "island"
        private const val YTM = "com.google.android.apps.youtube.music"
        @Volatile var ctlRef: MediaController? = null
        @Volatile var access = true

        @Volatile var inst: IslandService? = null

        fun playSearch(c: Context, q: String) {
            val s = inst
            if (s == null) {
                Toast.makeText(c, "Чолка не запущена (увімкни у Спеціальних можливостях)", Toast.LENGTH_LONG).show()
                return
            }
            s.h.post { s.ownSearch(q) }
        }
    }

    internal val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: Root? = null
    private var web: WebView? = null
    private var mode = "mini"
    private var msm: MediaSessionManager? = null
    private var ctl: MediaController? = null
    private var artKey = ""
    private var artB64 = ""

    // ---------- власний плеєр (грає без YouTube Music) ----------
    private class Track(val id: String, val title: String, val artist: String, val path: String? = null)
    private var pw: WebView? = null
    private var msess: MediaSession? = null
    private var wake: PowerManager.WakeLock? = null
    private var queue: List<Track> = emptyList()
    private var qi = -1
    private var oHas = false
    private var oPlaying = false
    private var oTitle = ""
    private var oArtist = ""
    private var oArt = ""
    private var oPos = 0L
    private var oDur = 0L
    private var oAt = 0L
    private var lastPush = 0L
    private var endHandled = false
    private var loopQ = false
    private var mp: MediaPlayer? = null

    private val listenerCn by lazy { ComponentName(this, MediaListenerService::class.java) }

    private val sessCb = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    private val ctlCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { refresh() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { push() }
        override fun onSessionDestroyed() { refresh() }
    }

    private val poll = object : Runnable {
        override fun run() {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isInteractive && !oHas) refresh()
            h.postDelayed(this, 5000)
        }
    }

    inner class Root(c: Context) : FrameLayout(c) {
        private var x0 = 0f
        private var y0 = 0f
        private var t0 = 0L
        private var tracking = false

        private fun openIsland() { web?.evaluateJavascript("setOpen(true)", null) }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (ev.action == MotionEvent.ACTION_OUTSIDE && mode == "open") {
                web?.evaluateJavascript("closeIsland()", null)
                return true
            }
            if (mode == "mini") {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { x0 = ev.rawX; y0 = ev.rawY; t0 = ev.eventTime; tracking = true }
                    MotionEvent.ACTION_MOVE -> if (tracking && ev.rawY - y0 > dp(12)) { tracking = false; openIsland() }
                    MotionEvent.ACTION_UP -> {
                        if (tracking && abs(ev.rawY - y0) < dp(30) && abs(ev.rawX - x0) < dp(30) && ev.eventTime - t0 < 700) openIsland()
                        tracking = false
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        if (tracking && ev.eventTime - t0 < 500) openIsland()
                        tracking = false
                    }
                }
                return true
            }
            return super.dispatchTouchEvent(ev)
        }
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> onCfgChanged() }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (root != null) return
        running = true
        inst = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        buildOverlay()
        buildPlayer()
        onCfgChanged()
        getSharedPreferences("cfg", 0).registerOnSharedPreferenceChangeListener(prefsListener)
        try { msm?.addOnActiveSessionsChangedListener(sessCb, listenerCn) } catch (e: Exception) {}
        try {
            val f = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
            f.addAction(Intent.ACTION_SCREEN_ON)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(volRx, f, Context.RECEIVER_EXPORTED)
            else registerReceiver(volRx, f)
        } catch (e: Exception) {}
        h.post(poll)
    }

    private fun onCfgChanged() {
        applyLayout()
        web?.evaluateJavascript("if(window.cfg)cfg()", null)
        val on = getSharedPreferences("cfg", 0).getBoolean("on", true)
        root?.visibility = if (on) View.VISIBLE else View.GONE
    }

    private val volRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            pushVol()
            if (i?.action == Intent.ACTION_SCREEN_ON) refresh()
        }
    }

    private fun curVol(): Int {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = maxOf(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 1)
        return (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max).roundToInt()
    }

    private fun pushVol() {
        web?.evaluateJavascript("if(window.onVol)onVol(" + curVol() + ")", null)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlay() {
        val w = WebView(this)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("file:///android_asset/island.html")
        web = w
        val r = Root(this)
        r.addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root = r
        lp = WindowManager.LayoutParams(
            dp(110), dp(30), TYPE_ACCESSIBILITY_OVERLAY,
            FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCH_MODAL or FLAG_WATCH_OUTSIDE_TOUCH or
                FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS or FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        applyLayout(false)
        wm.addView(r, lp)
    }

    private fun applyLayout(update: Boolean = true) {
        val p = getSharedPreferences("cfg", 0)
        val y = p.getInt("y", 0)
        when (mode) {
            "open" -> {
                lp.width = resources.displayMetrics.widthPixels - dp(12)
                lp.height = dp(340)
                lp.y = dp(maxOf(y, 4))
            }
            "full" -> {
                lp.width = ViewGroup.LayoutParams.MATCH_PARENT
                lp.height = ViewGroup.LayoutParams.MATCH_PARENT
                lp.y = 0
            }
            else -> {
                lp.width = dp(p.getInt("w", 110))
                lp.height = dp(p.getInt("h", 30))
                lp.y = dp(y)
            }
        }
        if (update) root?.let { try { wm.updateViewLayout(it, lp) } catch (e: Exception) {} }
    }

    // ---------- медіа ----------
    private fun refresh() {
        val list: List<MediaController> = try {
            val r = msm?.getActiveSessions(listenerCn) ?: emptyList()
            access = true
            r
        } catch (e: SecurityException) {
            access = false
            try { NotificationListenerService.requestRebind(listenerCn) } catch (x: Exception) {}
            emptyList()
        }
        pick(list)
    }

    private fun pick(l: List<MediaController>?) {
        val list = (l ?: emptyList()).filter { it.packageName != packageName }
        fun playing(c: MediaController) = c.playbackState?.state == PlaybackState.STATE_PLAYING
        val n = list.firstOrNull { it.packageName == YTM && playing(it) }
            ?: list.firstOrNull { playing(it) }
            ?: list.firstOrNull { it.packageName == YTM }
            ?: list.firstOrNull()
        if (n?.sessionToken != ctl?.sessionToken) {
            ctl?.unregisterCallback(ctlCb)
            ctl = n
            ctlRef = n
            n?.registerCallback(ctlCb)
        }
        push()
    }

    private fun art(m: MediaMetadata?): String {
        val b = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART) ?: return ""
        val s = Bitmap.createScaledBitmap(b, 96, 96, true)
        val bo = ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, 70, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    private fun push() {
        val o = JSONObject()
        val c = ctl
        if (oHas) {
            var pos = oPos
            if (oPlaying) pos += SystemClock.elapsedRealtime() - oAt
            o.put("has", true)
            o.put("title", oTitle)
            o.put("artist", oArtist)
            o.put("playing", oPlaying)
            o.put("pos", pos)
            o.put("dur", oDur)
            o.put("art", oArt)
            o.put("id", queue.getOrNull(qi)?.id ?: "")
            o.put("fav", isFav(queue.getOrNull(qi)?.id))
        } else if (c == null) {
            o.put("has", false)
            o.put("access", access)
        } else {
            val m = c.metadata
            val s = c.playbackState
            val playing = s?.state == PlaybackState.STATE_PLAYING
            var pos = s?.position ?: 0L
            if (playing && s != null) {
                pos += ((SystemClock.elapsedRealtime() - s.lastPositionUpdateTime) * s.playbackSpeed).toLong()
            }
            if (pos < 0) pos = 0
            val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
            val key = c.packageName + title
            if (key != artKey) { artKey = key; artB64 = art(m) }
            o.put("has", true)
            o.put("title", title)
            o.put("artist", m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "")
            o.put("playing", playing)
            o.put("pos", pos)
            o.put("dur", m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L)
            o.put("art", artB64)
        }
        web?.evaluateJavascript("if(window.onMedia)onMedia($o)", null)
    }

    // ---------- власний плеєр ----------
    private fun buildPlayer() {
        val p = WebView(this)
        p.alpha = 0.01f
        p.settings.javaScriptEnabled = true
        p.settings.domStorageEnabled = true
        p.settings.mediaPlaybackRequiresUserGesture = false
        p.settings.userAgentString = PLAYER_UA
        CookieManager.getInstance().setAcceptCookie(true)
        p.addJavascriptInterface(PBridge(), "P")
        p.webChromeClient = WebChromeClient()
        p.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) {
                if (url == null || !url.contains("youtube.com")) return
                v?.evaluateJavascript(PLAYER_JS + ";window.__want=" + oPlaying + ";", null)
            }
        }
        pw = p
        // окреме крихітне вікно, не залежить від чолки (ні відкрита, ні закрита, ні вимкнена)
        val plp = WindowManager.LayoutParams(
            dp(4), dp(4), TYPE_ACCESSIBILITY_OVERLAY,
            FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        plp.gravity = Gravity.BOTTOM or Gravity.END
        try { wm.addView(p, plp) } catch (e: Exception) {}

        val ms = MediaSession(this, "Chilka")
        ms.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { ownPlay() }
            override fun onPause() { ownPause() }
            override fun onSkipToNext() { nextOwn() }
            override fun onSkipToPrevious() { prevOwn() }
            override fun onSeekTo(pos: Long) { ownSeek(pos) }
        })
        msess = ms
    }

    inner class PBridge {
        @JavascriptInterface fun state(playing: Boolean, pos: Double, dur: Double, ended: Boolean, href: String) {
            h.post {
                if (!oHas) return@post
                val id = queue.getOrNull(qi)?.id ?: return@post
                if (!href.contains(id)) return@post
                val now = SystemClock.elapsedRealtime()
                val changed = playing != oPlaying || dur.toLong() != oDur
                oPlaying = playing
                oPos = pos.toLong()
                oDur = dur.toLong()
                oAt = now
                if (ended && !endHandled) { endHandled = true; nextOwn(); return@post }
                if (changed) {
                    lastPush = now
                    updateSession()
                    push()
                    setWake(playing)
                } else if (mode == "open" && now - lastPush > 2000) {
                    lastPush = now
                    push()
                }
            }
        }
    }

    private fun setWake(on: Boolean) {
        try {
            if (on) {
                if (wake == null) {
                    wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "chilka:play")
                }
                if (wake?.isHeld != true) wake?.acquire(6 * 60 * 60 * 1000L)
            } else if (wake?.isHeld == true) {
                wake?.release()
            }
        } catch (e: Exception) {}
    }

    private fun updateSession() {
        val s = msess ?: return
        try {
            if (!oHas) { s.isActive = false; return }
            s.isActive = true
            s.setMetadata(
                MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, oTitle)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, oArtist)
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, oDur)
                    .build()
            )
            val st = if (oPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO
                    )
                    .setState(st, oPos, if (oPlaying) 1f else 0f)
                    .build()
            )
        } catch (e: Exception) {}
    }

    internal fun ownSearch(q: String) {
        Toast.makeText(this, "Шукаю: $q", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val res = fetchSearch(q)
                h.post {
                    if (res.isEmpty()) {
                        Toast.makeText(this, "Нічого не знайшов (перевір інтернет)", Toast.LENGTH_LONG).show()
                    } else {
                        queue = res
                        loopQ = false
                        playIndex(0)
                    }
                }
            } catch (e: Exception) {
                h.post { Toast.makeText(this, "Помилка пошуку (перевір інтернет)", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun unesc(s: String): String = try {
        JSONObject("{\"v\":\"" + s + "\"}").getString("v")
    } catch (e: Exception) { s }

    private fun httpGet(u: String): ByteArray {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", SEARCH_UA)
        c.setRequestProperty("Accept-Language", "uk,en;q=0.8")
        c.setRequestProperty("Cookie", "CONSENT=YES+1; SOCS=CAI")
        try { return c.inputStream.readBytes() } finally { c.disconnect() }
    }

    private fun fetchSearch(q: String): List<Track> {
        var body = String(httpGet("https://www.youtube.com/results?search_query=" + Uri.encode(q)), Charsets.UTF_8)
        if (body.contains("\\x22")) {
            body = Regex("\\\\x([0-9a-fA-F]{2})").replace(body) { m -> m.groupValues[1].toInt(16).toChar().toString() }
        }
        val idRe = Regex("\"videoRenderer\":\\{\"videoId\":\"([A-Za-z0-9_-]{11})\"")
        val titleRe = Regex("\"title\":\\{\"runs\":\\[\\{\"text\":\"((?:[^\"\\\\]|\\\\.)*)\"")
        val byRe = Regex("\"(?:longBylineText|ownerText)\":\\{\"runs\":\\[\\{\"text\":\"((?:[^\"\\\\]|\\\\.)*)\"")
        val out = ArrayList<Track>()
        val seen = HashSet<String>()
        for (m in idRe.findAll(body)) {
            val id = m.groupValues[1]
            if (!seen.add(id)) continue
            val end = minOf(body.length, m.range.last + 3000)
            val seg = body.substring(m.range.last, end)
            val t = titleRe.find(seg)?.groupValues?.get(1)?.let { unesc(it) } ?: q
            val a = byRe.find(seg)?.groupValues?.get(1)?.let { unesc(it) } ?: ""
            out.add(Track(id, t, a))
            if (out.size >= 25) break
        }
        return out
    }

    private fun playIndex(i: Int) {
        val t = queue.getOrNull(i) ?: return
        qi = i
        oHas = true
        oPlaying = true
        oTitle = t.title
        oArtist = t.artist
        oArt = ""
        oPos = 0L
        oDur = 0L
        oAt = SystemClock.elapsedRealtime()
        endHandled = false
        setWake(true)
        stopLocal()
        if (t.path != null) {
            pw?.loadUrl("about:blank")
            startLocal(t)
        } else {
            pw?.loadUrl("https://m.youtube.com/watch?v=" + t.id)
        }
        updateSession()
        push()
        Thread {
            try {
                val b64 = if (t.path != null) localArt(t.path) else
                    Base64.encodeToString(httpGet("https://i.ytimg.com/vi/" + t.id + "/mqdefault.jpg"), Base64.NO_WRAP)
                if (b64.isNotEmpty()) h.post { if (queue.getOrNull(qi)?.id == t.id) { oArt = b64; push() } }
            } catch (e: Exception) {}
        }.start()
    }

    // ---------- своя музика (без інтернету) ----------
    private fun isLocal() = queue.getOrNull(qi)?.path != null

    private fun stopLocal() {
        h.removeCallbacks(tickRun)
        try { mp?.release() } catch (e: Exception) {}
        mp = null
    }

    private fun startLocal(t: Track) {
        val f = File(t.path ?: return)
        if (!f.exists()) {
            Toast.makeText(this, "Файл не знайдено: " + t.title, Toast.LENGTH_LONG).show()
            oPlaying = false
            setWake(false)
            return
        }
        try {
            val m = MediaPlayer()
            m.setDataSource(f.absolutePath)
            m.setOnPreparedListener {
                if (mp !== it) return@setOnPreparedListener
                if (oPlaying) it.start()
                oDur = it.duration.toLong()
                oPos = 0L
                oAt = SystemClock.elapsedRealtime()
                updateSession()
                push()
                localTick()
            }
            m.setOnCompletionListener {
                if (mp === it && !endHandled) { endHandled = true; nextOwn() }
            }
            m.setOnErrorListener { _, _, _ ->
                Toast.makeText(this, "Не вдалось відтворити файл", Toast.LENGTH_LONG).show()
                true
            }
            mp = m
            m.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, "Не вдалось відтворити файл", Toast.LENGTH_LONG).show()
        }
    }

    private val tickRun = object : Runnable {
        override fun run() {
            val m = mp
            if (m != null && isLocal() && oPlaying) {
                try {
                    oPos = m.currentPosition.toLong()
                    oAt = SystemClock.elapsedRealtime()
                    if (mode == "open") push()
                } catch (e: Exception) {}
                h.postDelayed(this, 1000)
            }
        }
    }

    private fun localTick() {
        h.removeCallbacks(tickRun)
        h.postDelayed(tickRun, 1000)
    }

    private fun localArt(path: String): String {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(path)
            val pic = r.embeddedPicture
            val bmp: Bitmap = (if (pic != null) BitmapFactory.decodeByteArray(pic, 0, pic.size)
                else try { r.getFrameAtTime(1000000L) } catch (e: Exception) { null }) ?: return ""
            val s = Bitmap.createScaledBitmap(bmp, 96, 96, true)
            val bo = ByteArrayOutputStream()
            s.compress(Bitmap.CompressFormat.JPEG, 70, bo)
            return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            return ""
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
    }

    private fun ownPlay() {
        if (isLocal() && mp == null) { playIndex(qi); return }
        oPlaying = true
        oAt = SystemClock.elapsedRealtime()
        if (isLocal()) { try { mp?.start() } catch (e: Exception) {}; localTick() }
        else pw?.evaluateJavascript("window.__want=true;if(window.chPlay)chPlay();", null)
        setWake(true); updateSession(); push()
    }

    private fun ownPause() {
        oPlaying = false
        if (isLocal()) { try { mp?.pause() } catch (e: Exception) {} }
        else pw?.evaluateJavascript("window.__want=false;if(window.chPause)chPause();", null)
        setWake(false); updateSession(); push()
    }

    private fun ownSeek(ms: Long) {
        oPos = ms
        oAt = SystemClock.elapsedRealtime()
        if (isLocal()) { try { mp?.seekTo(ms.toInt()) } catch (e: Exception) {} }
        else pw?.evaluateJavascript("if(window.chSeek)chSeek(" + ms + ");", null)
        updateSession(); push()
    }

    // ---------- улюблені ----------
    private fun readTracks(pref: String): MutableList<Track> {
        val out = ArrayList<Track>()
        try {
            val a = JSONArray(getSharedPreferences(pref, 0).getString("list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val p = o.optString("path", "")
                out.add(Track(o.getString("id"), o.optString("title"), o.optString("artist"), if (p.isEmpty()) null else p))
            }
        } catch (e: Exception) {}
        return out
    }

    private fun writeTracks(pref: String, l: List<Track>) {
        val a = JSONArray()
        for (t in l) a.put(JSONObject().put("id", t.id).put("title", t.title).put("artist", t.artist).put("path", t.path ?: ""))
        getSharedPreferences(pref, 0).edit().putString("list", a.toString()).apply()
    }

    private fun loadFavs() = readTracks("fav")
    private fun saveFavs(l: List<Track>) = writeTracks("fav", l)
    private fun loadLocs() = readTracks("loc")
    private fun saveLocs(l: List<Track>) = writeTracks("loc", l)
    internal fun localChanged() { web?.evaluateJavascript("if(window.onFavs)onFavs()", null) }

    private fun isFav(id: String?): Boolean = id != null && loadFavs().any { it.id == id }

    private fun favChanged() {
        push()
        web?.evaluateJavascript("if(window.onFavs)onFavs()", null)
    }

    private fun nextOwn() {
        if (qi + 1 < queue.size) playIndex(qi + 1)
        else if (loopQ && queue.isNotEmpty()) playIndex(0)
        else ownPause()
    }

    private fun prevOwn() {
        if (oPos > 3000 || qi <= 0) ownSeek(0) else playIndex(qi - 1)
    }

    // ---------- міст JS <-> Android ----------
    inner class Bridge {
        private val am get() = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        @JavascriptInterface fun ready() { h.post { push() } }
        @JavascriptInterface fun cfg(): String {
            val p = getSharedPreferences("cfg", 0)
            return "${p.getInt("w", 110)},${p.getInt("h", 30)}"
        }
        @JavascriptInterface fun setMode(m: String) { h.post { mode = m; applyLayout() } }
        @JavascriptInterface fun toggle() {
            h.post {
                val c = ctl
                if (oHas) {
                    if (oPlaying) ownPause() else ownPlay()
                } else if (c != null) {
                    if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
                    else c.transportControls.play()
                } else {
                    search()
                }
            }
        }
        @JavascriptInterface fun next() {
            h.post {
                val c = ctl
                if (oHas) nextOwn()
                else if (c != null) c.transportControls.skipToNext() else key(KeyEvent.KEYCODE_MEDIA_NEXT)
            }
        }
        @JavascriptInterface fun prev() {
            h.post {
                val c = ctl
                if (oHas) prevOwn()
                else if (c != null) c.transportControls.skipToPrevious() else key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            }
        }
        @JavascriptInterface fun seek(ms: Double) {
            h.post { if (oHas) ownSeek(ms.toLong()) else ctl?.transportControls?.seekTo(ms.toLong()) }
        }
        @JavascriptInterface fun volume(p: Int) {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (p * max / 100f).roundToInt().coerceIn(0, max), 0)
        }
        @JavascriptInterface fun vol(): Int = curVol()
        @JavascriptInterface fun favList(): String {
            val a = JSONArray()
            for (t in loadFavs()) a.put(JSONObject().put("id", t.id).put("title", t.title).put("artist", t.artist))
            return a.toString()
        }
        @JavascriptInterface fun favToggle() {
            h.post {
                val t = if (oHas) queue.getOrNull(qi) else null
                if (t == null) {
                    Toast.makeText(this@IslandService, "Спочатку увімкни пісню через 🔍", Toast.LENGTH_SHORT).show()
                    return@post
                }
                val l = loadFavs()
                if (l.any { it.id == t.id }) l.removeAll { it.id == t.id } else l.add(t)
                saveFavs(l)
                favChanged()
            }
        }
        @JavascriptInterface fun favRemove(id: String) {
            h.post {
                val l = loadFavs()
                l.removeAll { it.id == id }
                saveFavs(l)
                favChanged()
            }
        }
        @JavascriptInterface fun locList(): String {
            val a = JSONArray()
            val fids = loadFavs().map { it.id }.toSet()
            for (t in loadLocs()) a.put(JSONObject().put("id", t.id).put("title", t.title).put("artist", t.artist).put("fav", fids.contains(t.id)))
            return a.toString()
        }
        @JavascriptInterface fun favToggleId(id: String) {
            h.post {
                val t = loadLocs().firstOrNull { it.id == id } ?: return@post
                val l = loadFavs()
                if (l.any { it.id == id }) l.removeAll { it.id == id } else l.add(t)
                saveFavs(l)
                favChanged()
            }
        }
        @JavascriptInterface fun addAudioFav() {
            h.post {
                val i = Intent(this@IslandService, AddAudioActivity::class.java)
                    .putExtra("fav", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (e: Exception) {}
            }
        }
        @JavascriptInterface fun locPlay(i: Int) {
            h.post {
                val l = loadLocs()
                if (l.isEmpty()) return@post
                queue = l
                loopQ = true
                playIndex(i.coerceIn(0, l.size - 1))
            }
        }
        @JavascriptInterface fun locRemove(id: String) {
            h.post {
                val l = loadLocs()
                val t = l.firstOrNull { it.id == id }
                l.removeAll { it.id == id }
                saveLocs(l)
                t?.path?.let { try { File(it).delete() } catch (e: Exception) {} }
                val f = loadFavs()
                if (f.removeAll { it.id == id }) saveFavs(f)
                if (oHas && queue.getOrNull(qi)?.id == id) {
                    stopLocal()
                    oHas = false
                    oPlaying = false
                    setWake(false)
                    updateSession()
                }
                favChanged()
            }
        }
        @JavascriptInterface fun addAudio() {
            h.post {
                val i = Intent(this@IslandService, AddAudioActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (e: Exception) {}
            }
        }
        @JavascriptInterface fun favPlay(i: Int) {
            h.post {
                val l = loadFavs()
                if (l.isEmpty()) return@post
                queue = l
                loopQ = true
                playIndex(i.coerceIn(0, l.size - 1))
            }
        }
        @JavascriptInterface fun openApp(k: String) { h.post { launch(k) } }
        @JavascriptInterface fun search() {
            h.post {
                val i = Intent(this@IslandService, SearchActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (e: Exception) {}
            }
        }
    }

    private fun key(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun calcIntent(): Intent? {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)
        val ri = try { packageManager.queryIntentActivities(q, 0) } catch (e: Exception) { emptyList() }
        val a = ri.firstOrNull()?.activityInfo
        if (a != null) return Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR).setClassName(a.packageName, a.name)
        val pk = listOf(
            "com.transsion.calculator", "com.android.calculator2", "com.google.android.calculator",
            "com.sec.android.app.popupcalculator", "com.miui.calculator", "com.oppo.calculator",
            "com.coloros.calculator", "com.vivo.calculator", "com.huawei.calculator", "com.motorola.calculator"
        )
        for (n in pk) packageManager.getLaunchIntentForPackage(n)?.let { return it }
        return null
    }

    private fun launch(k: String) {
        val pm = packageManager
        val i: Intent? = when (k) {
            "ytm" -> pm.getLaunchIntentForPackage(YTM)
            "gemini" -> pm.getLaunchIntentForPackage("com.google.android.apps.bard")
                ?: pm.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
            "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "calc" -> calcIntent()
            else -> null
        }
        try {
            i!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Не вдалось відкрити", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        running = false
        inst = null
        try { unregisterReceiver(volRx) } catch (e: Exception) {}
        h.removeCallbacksAndMessages(null)
        setWake(false)
        stopLocal()
        try { msess?.release() } catch (e: Exception) {}
        pw?.let { try { wm.removeView(it) } catch (e: Exception) {}; it.destroy() }
        getSharedPreferences("cfg", 0).unregisterOnSharedPreferenceChangeListener(prefsListener)
        try { msm?.removeOnActiveSessionsChangedListener(sessCb) } catch (e: Exception) {}
        ctl?.unregisterCallback(ctlCb)
        root?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        web?.destroy()
        super.onDestroy()
    }
}

private const val PLAYER_UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
private const val SEARCH_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

private val PLAYER_JS = """
(function(){
if(window.__ch)return;window.__ch=1;
try{Object.defineProperty(document,'hidden',{get:function(){return false}});
Object.defineProperty(document,'visibilityState',{get:function(){return 'visible'}});}catch(e){}
['visibilitychange','webkitvisibilitychange','pagehide','blur'].forEach(function(n){
document.addEventListener(n,function(e){e.stopImmediatePropagation()},true);
window.addEventListener(n,function(e){e.stopImmediatePropagation()},true);});
function V(){return document.querySelector('video')}
window.chPlay=function(){var v=V();if(v)v.play()};
window.chPause=function(){var v=V();if(v)v.pause()};
window.chSeek=function(ms){var v=V();if(v)v.currentTime=ms/1000};
setInterval(function(){
var v=V();if(!v)return;
var sk=document.querySelector('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern');if(sk)sk.click();
if(window.__want&&v.muted)v.muted=false;
if(window.__want&&v.paused&&!v.ended)v.play().catch(function(){});
var d=isFinite(v.duration)?v.duration:0;
var end=v.ended||(d>10&&v.currentTime>=d-0.9);
P.state(!v.paused,Math.round(v.currentTime*1000),Math.round(d*1000),end,location.href);
},1000);
document.addEventListener('ended',function(){var v=V();if(v)P.state(false,Math.round(v.currentTime*1000),Math.round((isFinite(v.duration)?v.duration:0)*1000),true,location.href)},true);
})();
"""
