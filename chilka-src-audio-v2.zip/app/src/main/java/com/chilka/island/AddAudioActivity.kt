package com.chilka.island

import android.app.Activity
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class AddAudioActivity : Activity() {
    private var toFav = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        toFav = intent.getBooleanExtra("fav", false)
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/mp4"))
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try { startActivityForResult(i, 1) } catch (e: Exception) {
            Toast.makeText(this, "Не вдалось відкрити вибір файлів", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, null, null, null, null)?.use {
                if (it.moveToFirst()) {
                    val c = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c >= 0) return it.getString(c) ?: "audio"
                }
            }
        } catch (e: Exception) {}
        return "audio"
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc != 1 || res != RESULT_OK || data == null) { finish(); return }
        val uris = ArrayList<Uri>()
        data.clipData?.let { for (k in 0 until it.itemCount) uris.add(it.getItemAt(k).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) { finish(); return }
        Toast.makeText(this, if (toFav) "Додаю в улюблені…" else "Додаю…", Toast.LENGTH_SHORT).show()
        Thread {
            var added = 0
            val dir = File(filesDir, "music")
            dir.mkdirs()
            val sp = getSharedPreferences("loc", 0)
            for (u in uris) {
                try {
                    val name = nameOf(u)
                    val raw = UUID.randomUUID().toString()
                    val mime = contentResolver.getType(u) ?: ""
                    var ext = name.substringAfterLast('.', "")
                    if (ext.length > 5 || ext.isEmpty()) ext = if (mime.startsWith("video/")) "mp4" else "mp3"
                    val f = File(dir, "$raw.$ext")
                    contentResolver.openInputStream(u)?.use { inp -> f.outputStream().use { inp.copyTo(it) } } ?: continue
                    var title = name.substringBeforeLast('.')
                    var artist = ""
                    try {
                        val r = MediaMetadataRetriever()
                        r.setDataSource(f.absolutePath)
                        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }?.let { title = it }
                        artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
                        r.release()
                    } catch (e: Exception) {}
                    val arr = try { JSONArray(sp.getString("list", "[]")) } catch (e: Exception) { JSONArray() }
                    arr.put(JSONObject().put("id", "loc:$raw").put("title", title).put("artist", artist).put("path", f.absolutePath))
                    sp.edit().putString("list", arr.toString()).commit()
                    if (toFav) {
                        val fp = getSharedPreferences("fav", 0)
                        val fa = try { JSONArray(fp.getString("list", "[]")) } catch (e: Exception) { JSONArray() }
                        fa.put(JSONObject().put("id", "loc:$raw").put("title", title).put("artist", artist).put("path", f.absolutePath))
                        fp.edit().putString("list", fa.toString()).commit()
                    }
                    added++
                } catch (e: Exception) {}
            }
            runOnUiThread {
                Toast.makeText(this, if (added > 0) (if (toFav) "Додано в улюблені: $added" else "Додано: $added") else "Не вдалось додати", Toast.LENGTH_SHORT).show()
                val s = IslandService.inst
                if (s != null) s.h.post { s.localChanged() }
                finish()
            }
        }.start()
    }
}
