package com.chilka.island

import android.app.Activity
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout

class SearchActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val box = EditText(this)
        box.hint = "Пісня або виконавець"
        box.setSingleLine()
        box.imeOptions = EditorInfo.IME_ACTION_SEARCH
        val btn = Button(this)
        btn.text = "▶ Знайти й увімкнути"
        btn.isAllCaps = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val p = (20 * d).toInt()
        col.setPadding(p, p, p, p)
        col.addView(box)
        col.addView(btn)
        setContentView(col)
        fun go() {
            val q = box.text.toString().trim()
            if (q.isEmpty()) return
            IslandService.playSearch(this, q)
            finish()
        }
        box.setOnEditorActionListener { _, _, _ -> go(); true }
        btn.setOnClickListener { go() }
    }
}
