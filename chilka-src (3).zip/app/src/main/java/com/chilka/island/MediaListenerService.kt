package com.chilka.island

import android.service.notification.NotificationListenerService

// Порожній сервіс: сам факт «доступу до сповіщень» дозволяє читати медіа-сесії (YouTube Music).
class MediaListenerService : NotificationListenerService()
