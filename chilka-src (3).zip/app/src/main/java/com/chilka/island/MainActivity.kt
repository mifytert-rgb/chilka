package com.chilka.island

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("cfg", 0) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(28), dp(20), dp(28))
        setContentView(ScrollView(this).also { it.addView(col) })

        col.addView(android.widget.ImageView(this).also {
            it.setImageResource(R.drawable.banner)
            it.adjustViewBounds = true
            it.scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        col.addView(TextView(this).also { it.text = "Чолка"; it.textSize = 30f; it.setTypeface(null, Typeface.BOLD) })
        status = TextView(this).also { it.textSize = 15f; it.setPadding(0, dp(10), 0, dp(10)) }
        col.addView(status)

        btn(col, "1. Увімкнути Чолку (Спеціальні можливості)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn(col, "2. Доступ до сповіщень (для YouTube Music)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn(col, "3. Не обмежувати батарею") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        col.addView(CheckBox(this).also {
            it.text = "Показувати чолку"
            it.isChecked = prefs.getBoolean("on", true)
            it.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("on", v).apply() }
        })

        col.addView(TextView(this).also { it.text = "Положення на камері"; it.textSize = 18f; it.setPadding(0, dp(18), 0, 0) })
        slider(col, "Ширина", "w", 60, 240, 110)
        slider(col, "Висота", "h", 20, 70, 30)
        slider(col, "Відступ зверху", "y", -10, 40, 0)

        col.addView(TextView(this).also {
            it.setPadding(0, dp(18), 0, 0)
            it.text = "Крок 1: Спеціальні можливості → Завантажені додатки → Чолка → Увімкнути. " +
                "Якщо перемикач сірий: Налаштування → Додатки → Чолка → ⋮ → Дозволити обмежені налаштування. " +
                "Tecno: також увімкни Автозапуск для Чолки."
        })
    }

    private fun btn(p: LinearLayout, t: String, f: () -> Unit) {
        p.addView(Button(this).also { it.text = t; it.isAllCaps = false; it.setOnClickListener { f() } })
    }

    private fun slider(p: LinearLayout, title: String, key: String, min: Int, max: Int, def: Int) {
        val v = prefs.getInt(key, def)
        val t = TextView(this)
        t.text = "$title: $v"
        val s = SeekBar(this)
        s.max = max - min
        s.progress = v - min
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, pr: Int, fromUser: Boolean) {
                val x = pr + min
                t.text = "$title: $x"
                prefs.edit().putInt(key, x).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        p.addView(t)
        p.addView(s)
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.Secure.getString(contentResolver, "enabled_accessibility_services")?.contains(packageName) == true
        val nl = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        val bat = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        fun m(x: Boolean) = if (x) "✅" else "❌"
        status.text = "${m(ov)} Чолка увімкнена (Спеціальні можливості)\n${m(nl)} Доступ до сповіщень\n${m(bat)} Без обмежень батареї\n${m(IslandService.ctlRef != null)} Плеєр: ${IslandService.ctlRef?.packageName ?: "не бачу (увімкни музику)"}"
    }
}
